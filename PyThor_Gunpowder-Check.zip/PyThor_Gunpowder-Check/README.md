# PyThor_Gunpowder-Check
Redm script to check gunpowder on players as a lawman

How to use the script in your server:

- Add it to your resources folder
- Add `ensure PyThor_Gunpowder-Check` to your server.cfg

Dependecies 
- vorp-core
- vorp-progressbar

Description:
to check a player simply go near him and use the command in the config with the player ID 
example: /gp 1
you will get notify if the player clean or not.

PLEASE DO NOT CHANGE THE RESOURCE NAME TO GIVE CREDIT (please)!